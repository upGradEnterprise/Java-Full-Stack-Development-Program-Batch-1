package com.example.SbSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbSecurityApplication.class, args);
	}

}
