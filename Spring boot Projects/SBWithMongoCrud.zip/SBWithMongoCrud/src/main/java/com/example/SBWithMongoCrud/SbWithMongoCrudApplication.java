package com.example.SBWithMongoCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbWithMongoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbWithMongoCrudApplication.class, args);
	}

}
