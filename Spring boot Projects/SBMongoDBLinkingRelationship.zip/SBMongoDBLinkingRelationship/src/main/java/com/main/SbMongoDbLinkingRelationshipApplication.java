package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbMongoDbLinkingRelationshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMongoDbLinkingRelationshipApplication.class, args);
	}

}
